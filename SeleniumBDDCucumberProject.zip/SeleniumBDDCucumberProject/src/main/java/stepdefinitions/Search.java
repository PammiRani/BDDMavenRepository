package stepdefinitions;

import factory.DriverFactory;
import io.cucumber.java.en.*;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import pages.HomePage;
import pages.SearchResultPage;

public class Search {
    WebDriver driver;
    HomePage home;
    SearchResultPage searchResultPage;
    @Given("User open the Application")
    public void user_open_the_application() {
        driver=DriverFactory.getDriver();
    }

    @When("User enters valid product {string} into search box field")
    public void user_enters_valid_product_into_search_box_field(String searchProductName) {
         home=new HomePage(driver);
          home.searchOnInputBox(searchProductName);
    }

    @When("User clicks on Search button")
    public void user_clicks_on_search_button() {
        searchResultPage=home.clickOnSearchButton();
    }

    @Then("User should get valid product displayed in search results")
    public void user_should_get_valid_product_displayed_in_search_results() throws InterruptedException {
        Thread.sleep(1000);
        Assert.assertTrue(searchResultPage.displayStatusOfValidProduct());

    }

    @When("User enters invalid product {string} into search box field")
    public void user_enters_invalid_product_into_search_box_field(String invalidProductName) {
        home=new HomePage(driver);
        home.searchOnInputBox(invalidProductName);
    }

    @Then("User should get a message about no product matching")
    public void
    user_should_get_a_message_about_no_product_matching() {
        Assert.assertEquals(searchResultPage.getMessageText(),"There is no product that matches the search criteria.");
    }

    @When("User don't enter any product name into search box field")
    public void user_don_t_enter_any_product_name_into_search_box_field() {
        home=new HomePage(driver);
    }




}
